package com.ngotran.ngotran;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;

public class FloatingService extends Service {

    private static final int C_SURF = 0xFF0A0A0A;
    private static final int C_RED = 0xFFFF3131;
    private static final int C_RED_D = 0xFFD02828;
    private static final int C_WHITE = 0xFFFFFFFF;
    private static final int C_SEC = 0xFFD1D1D1;
    private static final int C_MUT = 0xFF888888;
    private static final int C_GREEN = 0xFF00FF00;
    private static final int C_YELLOW = 0xFFFFD700;
    private static final int C_TRK_OFF = 0xFF2A2A2A;
    private static final int C_THM_OFF = 0xFFD1D1D1;
    private static final int C_BORDER = 0x1AFFFFFF;
    private static final int C_HDR = 0xFF141414;

    private static final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static final float SCALE = 0.8f;

    // TODO: Paste your Base64 image string here
    private static final String ICON_IMAGE = "iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAALxUExURUdwTBsQCAwFAQwGAEsfEAoDAAQCAg0FAg8FAwYCAgYCAwAAAAQBABIIBJBTMVAtJlspKAMBAwQCAwcCBY9GL2IrItRzJ+hrJUkhGAoFBwoCBgcCBZU2JdFeIM5SJAYDBXcqHP9+Gqc9HtVuJ/50FzgWEwcEBgMBBPZrIAUEBnYbFfRQHPtgGDcVFcNhH/9sFHEwI/tYEf13FzcbFgYDBV4ZFP9iD+MaEAQCA+suF/NEIINDHNlGG9YpGf9sGdtrHjYPEPYxFP4rD1AVFQYCBAgGCAMBBHITE/47Ef5nJ1clG/9ZDbAgGhkPCooqEK1FIQYCBs4ZEv9EGuVHGhUGCAEBBUAREfRLJZMTD/ZqIlUeFQIAAxYQD31EKP8hDdk2HwcDBgwDBx4MDe43IPgbCUQWErlhJ/YmEmcuJgEAAu0jF/FyHMJEIv4ZBdggDUouIwkEBGg3JjYnJKhbLQIABGZGL+B0MU0JC/VaKHcxHrhRLMVPIyQMEEAgGzwcGUsnHSISEi4OEFo5IsokGfyHGotRJ78UDOIoEJs5IMJSPtJLG+JZOP9ZHaFdH5UlGT0bE5ReNZgkFuBOHnchFLJFJf9RGLAzJMA1IKIiHfQ9EJ45I/9JBmMfGQwFB9JTLYcsHcAdFScZE/9BA/lHB/5QBetUHEwgGiMYFbshFg8EBuU5FI1CMAgGDXg+MSISEO5gKHAhGYEaF8goEwEAAAIBBgoBAmEWEWE7IkgmGxgQELlNJz4GCJ5WKf51Kd5cKG4/K6t3RBECAiUICBUCAsFyNFwHCOiFORIMEP19K9BkMi4YFpE2ImIHBlMEBC4HCBoDBIdpTHdQNGwICK0SD41HGUcDA1knIMqCN3YKBuCBK/BtKrVDHmJJNx8DAv9OA/9TBZBFKq1CHBcdJydETeh4Pf1mGPJkEf1GDHcpH/5QF/dYFP9FDPE/GvxQC/FrH/hnHP5lFPaEK/9kEP9RAPh8M/9CBIY3FP5WCP1aEHFDK////0HftewAAAD6dFJOUwABBQgCAxoNCiEmEBUEP4RHVnFLcXH3yaa1qYurpd5kuP7PwfzH0Mb8vvH+9er0/JP76t3h6fz9Qv7+4P789vL5/f762YDm/P771P36Nebr8P38+vb3+/b87PUt8/n9/O347/79+e39/Pr++vf9/vg8tv388+bm/v39zuj8+7uQzf353/r4/f3f+Pf+/fjBYfj68NCS/vv9/P73/fiZ+/r09Pz89Pv6+/7+/v79feT6/P3+/v7+/drp/f7+5ef+/ff+/v77/v7+9v7+/P7+/v78/P79+v79/P79+Nr2/v380Pv+/vfTIOXnaoC2lNVfqODUwse1yPzps9f4cGUuAAAAAWJLR0T61W0GSgAAAAd0SU1FB+oEBQ4gCCiURSwAABILSURBVGje7Zp5XFNn1sez3OyJGnAD1IDFsAhVMCKoUIEQUKCGQBQBJSAUrsoixiIIrVJFReoe2UQGWYOU7d4ggaoTYgQhITUW3ArIjL5aZ2ip7dT2v/e5QVvbUhJnPvPX+54P8uFz8+R8n/M751mvONz/2/9Vw/8XXRuNQHxLBB6CcBABb863SAQCiUimTN0Uj7mY6iMSkUSl0Rlm9J9BoTJZM2ZSIBI0dXivYjT++YtBEHEW28LCkk40RYBmz2HSiLPnWuKIBGgq/1O5x0ME3Ix5862sbRbMwEHT+sfjFi7i0C1t7RbTcRTCH51DmJFIEPSmTBCLiKO8Y7+E67DEcfb0APC1Bfa2Fk7O9kttGVTqb71jjknAWCBJ0JufsPA4ygJ7F1cu991l8wnTVyAet9zNfQVvpYfbqvmedBz+zayC7pNYLBZAvNFJPIRnETw5872WrXZ1WGO/1poyfSWRcJbePu/x1vk6+vnzA4wu39QD/4dvQwBJcxIEBq335m1wDw6xJkMmIgh939d+ozBMFB4htiaCksUE+fPWYMAQqWRr4abNokjeFh/fKKfoaSXC4+jWMWG+9lsDt8UKJTZMBkgEdZpBB/xTmExqQFz89oTED+yTQiR89rQACDcjGV6XsGPnrpRUcdryUM90OpnOZPxJ4vAMBpFIjg6N3p0RkbRqj0vCqgjp3lnTlhGEI3+4Jy4zJWGfr7c4K9vCxppDpzOZZGgK9fEQOZRJoNA4Njb7EyOSVm9OWZUT/+47jOmrCAJl+l7uplUpft5i5y1WTryPPg7gWKYzjQMUZPs1BxsRuGhLS4uPZzpwD+zblJOUkBJ2MM99/RwTAw3C0T8JPnQ4Nz/liDjK5Sif73qs4OgSGw7bk8ZkvWoC6tRICQ2wPVpwPE3K31gYk7gtITL300OFJ5imJmIIdzIsyOe9U0eSNsW7iVYKBDmnN28+s/HsRzYWHEsygUWdHN5E8oxzG8NlovPrxMKVogLh6W1Fn7qvFxVzTAQAYqdSZnpvK/HZubSUt6tsxwWJUBrvXCSSbd6/eMMBBysrJ6tyG5ty26MXl8pksRUHxWJp1A5ZcnzsPke3Er+QACqFZAKAo9I4B/6SkpDk67uyct+lpAqhVCqNS6yIraourNlVURsfn5tVVBMsC4o9nRgHi4VC5yTRHul5P9+ElG2n+TbpTFMrAh7n6eDAd/ZKSUnxra27KPOrXyeWS3mC+AvF3g1lMllNTaFMVnKk+EIODMNx4nUhfoWXG0/7paRs847iCbgckikAhPtsaxOPy3VOTUjxjRJnNZd5tYglAolUGpHYWu/dUFXV0FbfukmOoIq4GKmzl+hibmPxtpQd+e1SiaRpr6kiwgChi9bP/XTNlY5S3xS/043KzkK/lrQOaVycAmlc13K6vr64/SCKIAoFmra3NQh0v8vbz68hq+PKms/nXs1ON72ak3ChJ1YX2ru7v3etLTVoeyJ6fZ9X51+lsFylUqFwjr9/N4Ko1QoAuLHLtzmtsULkl7p25053d3eXcNt0yFQAIAQijrYkctU2v23bwgI1keeT0dzmkpt1GUqFSq6SK1AUBSS1oicjo7fkVp+yP0Sb2ZqaApp7O1tH40imATgWxdNKKPSPzF+VsKNYN6DJRHKb7a7/NUKhNppKrdarVYqeL27bX6tT+HcNGNoSElLvtLryHWyiiSZzjNURZLEiJiamMu3La6v9guoNukF0qPfyDSEMHGM/2D8Vorzb6din1unugQwsvfZlWmUT98BH6XgzAgBpnnXMceehQ4fsl/oeqW87H6jLRG/vuR8Dx8UBceLkKqC/HEm7uee6QqdrLWqrT/Vdag+ab3kA1nFzAKAOTj7cHhTkl5CSsqPY0DU4qB1A8w7lwetqUTnyVRqiQob60BuOGY2DGt3gYGD9jpSUBL+goNgTbJY57o1GmXWiOOxIkld9fUNb6+CgTq13nCtuvwiq/+4pBFEe78qz60QHNIODkd6xIW1JSUfaTp89STXbPShVHJsnjOjOuX7LRRS0vVXThXauv50py8povHm3Ma9f5H9fdhnN1LV6BcncOjP0OT1iniUOzzJLoMk8QOfOO0vFe+zKUu9ERgbqdIo80fH+Bln40KH7lwtlqcdWr84Y1g22R0aGHQneeR1pDNz1GYVCMBuAxxEWlETG3LAP2tGa29LaCrRGO7flN4xcKrF3rLpU1hbmdxnVZd6LPN0yFJJ06dDhnsggWzrxbQDUE14h95dtL97Ud8teFqsBeVZeW5Vasj3IbbTEqyQ/9ZayS6MzbJct6+xr8Q6yu3Un6Swd/zYA4oL1vTXFm9DGuXYl9RptOxAp41ZQQ733SFnbHa+SWxlynU6rMbT52u9p7GkvWuZYaMuAzBllrwHkR9dac2AE3Wrnm1TsvT1wUDt8fWhMln+npCGyLbj0wlY9ADQUVewosbuOIOimkKW2VDPmoTcAJ7zu5CgUyvsjXi39QSGDGq2+ouhvWbL8tvx8WXJPfdawVjcYKWpp8fO436NADt7xsqWy3uLMAlEXrM5fh8Cn7GMTc1Z7a4Btyij64u9ZstYikf/frxdlDGh0Wp13bGP7drvDCJKZv3o35S2qFMciLl8dlginPT6dgxSLIgcHdNp1XzxoSEazMvKG0OTYB190GTIHdIGiFuTg2M0MpD2sZj7lLSTCsZgzw8Pa4cocBGlc29Yl79YaBjPu2sn80S9uI0PBdndzNVqtfkDnXQQS0JeBBqautSZTIfM1IjBOnkkNhBFEpVCG35MrtAaNtqt767Xmoftzh651Zg0MajT3NKg6MhbMfWB5izxy0SqUac5i8BpADF2UFNmoUOsVA50D6EB7TqbBoOsaSL5lv/PWkL5Lp9VmDhi6ka7zwyq9WqG/47Wx3JNGMD8EiEDOLgmJQPR61fAmuWqgW23Qdg8aNKo0O7tcvfZeV7fBIB8YUOtzh0ET5GD+6jXW6QyTW6JfDQ9RbJf+JRFR6fXYKjMsH9CC7hq0OsWNPQqD1jCADmu6wXO9Wo8B2sP2dXia7x0DEIkza44EogrQweFh4Kdbr1KBnhu6MjJ0BoMG1SuGsefYL7ABaPW6ZoMzfxxjACrZclFVcYTC6N/oZljV3WUw3BvoumfQAnFeux8GAXSHyLLfpoQwI1GibQs/cYXjgAwA0g0IasPggEZ7755Go+8yqAAPi06lV6mRdq8n/2PeYvmbQuLMe/pMEhFXl2bUSa/X3BtQqLoNWiBJ171B0H+gvyK3W6GIu/P03/APAqZ+/ckKniT+WBQK/A9narvUiLJHrZLLFSCETGN2h47J1cim7c9xv57ZzboPeY34+oQDX1C6fggFAwIkE+m7LP9bT/flPhTB9i4KtGX9ZVQhLv4H8c0EmE+AIMo/P3LgN51Z39+NgM2cPPl4q/Jysvz88Sw1ogLV31l4UalAdOG/E8gMwqujGJ719TlrB57rsX3Hk+VIRkGhV1d/UfGQf4mssw8FuH2dfYhCHTsO/dalCYDxToI1GTP1m+cLnPiSiINDtfKDNYUNd/rWrq3vH6hvkBXI5X3ruhWIAj0tW8SC3gKAh1jg8E6gUKkUCoU26+t/2nIFQhhRIBX7+uvbe8KrGsbQ1uKKfUMINskp1MWFNX3pOMLkLQzeNAAPEagUBjM6PZpOp0enW845t+CAQIoBcnMa/VFkrCyoH9X7I319GABBcs+X5iJ8+u80mC6xBCqTOWvOyZOzQoFZcgLKrQ40VVbW1TWiyrq6HqRWtvQgoqzr6wG/jBYjkcbnrpgzA7NQ4wFteoFIRAaN/s23z59//Q2wkwHnvp33ZGJiy5bHafCN3qu5CHo5GUFu9/ZuRU/1Nj9w3LLlarZ473cTT148AY0+nEnBm5iR8AQKOTr0+ff/WHju3PPnz5eX//Cv8TMFBWeqqyvE7466JSIKJSjM2x6jP6KfelRVh4eH12wU752oGs9++PDMy4nPCHgTUzYEAki3XPh0fIOD1fyfftrtNG98vyRO3NFc/b7QCPjq8eM0IwD+1GOkVBwHzofiKxNVi52sHda8fDkbB5kEMOme7IXVLzt4/APj42f5H74cE8uRFVuq35d8MOLWp3w8MnIRvm4EBJeNuXZ0rODBV55ULw7glD8aN0YwvUQkI+CdkerDX+39/OXLZ5IH1WMwAEy8BIBRt7pTHmvXBifnTQKqRl18fK42iTHAzG8WznvxzkkMgDcVQbrlOyOXgn18fKpdhuIejI6BA4criED4wWj4bUdZ7pDH2lOTgEsFpaVjR+PhvRMjiw98+/34Ak40lcAyASAwaKGe80ZGzmdVVPRnNSofjHYiCNy0xZiDqubgMRjuHG12G/0RARL1S8VSgQADPORvePH9wvRoJsFEBHgWlUmP/m5EVosYTbmzrObyj1s/d6l+XwoAIzU5YErdN1JlTHJZwdYvD39+RbJ3onoxT/DoxYtzbBqFSjI5DpjRH3qsH0LkCgU4rN7w8Fi2zMfHbX2e+May4GXJqFyO/gj++BLeYx/sAXR0zxb8fNXloVQqyH7xw2xPGsXEDhViUUnlaReGlJMRIPLaocTExNoLiTCaERVV24iCZ421UVF9cGUt+MA/aqWruLIjylUihrnLl8+0iJ52b4SHwExKZFiB7SCq7DNaDywFZ2YxDCsr44WwGMwZlZWVMRIYjagEz5UxfL6A6+RkZXXgwAFrCw47nWECwAJTEZlug6B1Nx0dr4KJ4BGv6bHL4zo5+lWvz1Y0r7d5y1V3995TaN1dxy0+Pi6OH3KbfvgWs59++JjDtiQziNMCSAQClcEkMzn8NJ9Lix5u3Lj/iqDyQVlNBIJs9RipgPOWXQofGxvrvI7m2l8KLy1dW+aygpv9cNH4v7Kzsz+yCPWkMaZ9RwERiFQKk0wm0yw+mni6hCcAJql8cKmmUqkEtV+BAECpFJgYybMfqRCLrwe7dfC4Dlcmxuewra0s6PTpIwABgLUA+CeHWsyfeLpCIJRIhNLKnZeqHgCrGu3HAOH79+//PAabjpKl8FceoysFPO7PE+Oz2eU2bAxAmE4h1mQATCbNYv4TAJC8AiwFE2oNAGASVZ+pcdkfgRz2qLr4wQfvjY5e4fP4APAZJ8DCkk6mEFlmAMgMMufjJ0+XOHC5fJ6kcmdZAZhQDwdPAjZKpEKhFN4TXFXT3Ayojxz4RgA7gAMyQGSRTACoQCImg8ye+eLp4vm7d+9eIqjcOVogVcCHPSYBuzo6OjY0iW+MLM1tbExzGT3qwOf9/OKnOWwLdiiNSWRN+eLn1xyD5RiTiMz++IenL588mfjuEc+1N/hMnBw+5eNRCuf1lmGj9+oa8U2P5hwEzuj1eAgieHT1yWdsjmU0SLEJAKhRTCIy0zJg/tmzZ585O7sKmp45RwGA68qVlXBdcjtmLeukaRfAw7j4ZxUd/Hj+kmfPlgSwPelMkIIpiuiXWyqIiG0oQABMRjSHExBgYWFT7uTAByOVL4zgbVjpHwfmCRiGxVJJ1MoOnjBC4lBebm1TXm7B4YAM05lUkII/AvC/rHIQ2AsxQAwMBoVGA+2x9xIsCt2TY2MNNpDPNouKElGFXC6Wuu7avPlZk4APJgcOOzo6mk5jgn0Ug0ggQVMMMzzpdWVBxs0WBqD+9p0HmW3twBU0nReJKiLE4piKzaLz8VKhlSWZGWrBSQ8FCFAYFMz/VAAw/7x6SMICABEY77dfb0/xxv0azcYBlOyFWFH4hQvhojMrJXFObOMFF8MSA9DJWAgE1tQAAvWVRiQsxUzyH2/GwF6EYePE5QniS0XASuOFXAvQCngj4WieAEADAArIADQVAcwPr04PLKxCmVPevEE4KtsKEARRBbG1Yp4NDTd55sPjKaFgk4kphEUwpUagNl+94CSQiX96EAJfowdYcbncphheOR3365GSCjIMqoJKJACFgKB/fNdDoLzuNGm6TRNQg5rOsXYAc+Yb7vE4Mo2M9R5syI01hJ8KwDD5ivaVTKAx9sb4zVsVAo1GxuSfBBhz8HsAmB7MvPDEGz3/7saDxCRTXoXAekX4fQQMpvk3qvgpBioDGzdUAoiANFUAIMkU8yT6MyMY+298TQtNkQIci0ol/Dt+3/BAwFLAMio0JeA/jGBSOpIxgqlCMD/JJiHQlEkm/scSvQmZogow/f6b/w/kfwGcO1dY5hKAiQAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAyNi0wNC0wNVQxNDozMjowOCswMDowMB4Snz0AAAAldEVYdGRhdGU6bW9kaWZ5ADIwMjYtMDQtMDVUMTQ6MzI6MDgrMDA6MDBvTyeBAAAAKHRFWHRkYXRlOnRpbWVzdGFtcAAyMDI2LTA0LTA1VDE0OjMyOjA4KzAwOjAwOFoGXgAAAABJRU5ErkJggg=="; // e.g.,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     // "data:image/png;base64,iVBOR..."

    // ── WindowManager ─────────────────────────────────────────────
    private WindowManager wm;
    private View fabView;
    private LinearLayout menuView;
    private boolean menuVisible = false;
    private TextView logoView;

    private WindowManager.LayoutParams menuParams;
    private WindowManager.LayoutParams fabParams;

    private FrameLayout contentHost;
    private int curTab = 0;

    private ESPView espView;

    static native void Draw(ESPView espv, Canvas canvas);

    public static native String getFeatureList();

    public static native void Changes(
            Object obj, int featNum, String featName,
            int value, float floatValue, long Lvalue,
            boolean booleanValue, String text);

    public static class FeatureState {
        int id;
        String name;
        boolean enabled;
        int intValue;
        float floatValue;
        String stringValue;

        FeatureState(int id, String name, boolean enabled) {
            this.id = id;
            this.name = name;
            this.enabled = enabled;
            this.intValue = 0;
            this.floatValue = 0f;
            this.stringValue = "";
        }
    }

    private HashMap<Integer, FeatureState> featureStates = new HashMap<>();

    // ════════════════════════════════════════════════════════════
    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startForegroundCompat();
        addFab();
        addESPView();
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) {
        return START_STICKY;
    }

    @Override
    public @Nullable IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (fabView != null)
            try {
                wm.removeView(fabView);
            } catch (Exception ignored) {
            }
        if (menuView != null)
            try {
                wm.removeView(menuView);
            } catch (Exception ignored) {
            }
        if (espView != null)
            try {
                wm.removeView(espView);
            } catch (Exception ignored) {
            }
        super.onDestroy();
    }

    // ════════════════════════════════════════════════════════════
    // NOTIFICATION
    // ════════════════════════════════════════════════════════════
    @SuppressLint("ForegroundServiceType")
    private void startForegroundCompat() {
        String channelId = "Power_overlay";
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    channelId, "Power Overlay", NotificationManager.IMPORTANCE_MIN);
            ch.setSound(null, null);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        Notification notif = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notif = new Notification.Builder(this, channelId)
                    .setContentTitle("Power MODS đang chạy")
                    .setContentText("Tap để mở menu overlay")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .build();
        }
        startForeground(1, notif);
    }

    // ════════════════════════════════════════════════════════════
    // ESP View
    // FLAG_NOT_TOUCHABLE đảm bảo touch xuyên qua lớp ESP
    // ════════════════════════════════════════════════════════════
    private void addESPView() {
        espView = new ESPView(this);

        int iparams = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? 2038 : 2002;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                MP, MP,
                iparams,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
                -3); // -3 = PixelFormat.TRANSLUCENT

        params.gravity = Gravity.TOP | Gravity.START;
        wm.addView(espView, params);
    }

    // ════════════════════════════════════════════════════════════
    // FAB
    // ════════════════════════════════════════════════════════════
    private void addFab() {
        fabView = buildFab();
        fabParams = overlayParams(dp(56 * SCALE), dp(56 * SCALE));
        fabParams.gravity = Gravity.TOP | Gravity.START;
        fabParams.x = dp(16 * SCALE);
        fabParams.y = dp(120 * SCALE);
        fabParams.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;

        fabView.setOnClickListener(v -> toggleMenu());
        fabView.setOnTouchListener(new DragTouchListener() {
            @Override
            protected WindowManager.LayoutParams getParams() {
                return fabParams;
            }

            @Override
            protected View getRootView() {
                return fabView;
            }

            @Override
            protected void onClick() {
                toggleMenu();
            }
        });
        wm.addView(fabView, fabParams);
    }

    private View buildFab() {
        if (!ICON_IMAGE.isEmpty()) {
            ImageView iv = new ImageView(this);
            Bitmap b = decodeBase64(ICON_IMAGE);
            if (b != null) {
                iv.setImageBitmap(b);
                iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                int p = dp(8 * SCALE);
                iv.setPadding(p, p, p, p);

                iv.setBackgroundColor(Color.TRANSPARENT);
                if (Build.VERSION.SDK_INT >= 21)
                    iv.setElevation(dp(8 * SCALE));
                return iv;
            }
        }

        TextView fab = new TextView(this);
        fab.setText("P");
        fab.setTextColor(C_WHITE);
        fab.setTextSize(22 * SCALE);
        fab.setTypeface(null, Typeface.BOLD);
        fab.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[] { C_RED, 0xFFFF7B4B });
        bg.setCornerRadius(dp(28 * SCALE));
        fab.setBackgroundColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 21)
            fab.setElevation(dp(8 * SCALE));
        return fab;
    }

    private Bitmap decodeBase64(String input) {
        try {
            if (input.contains(","))
                input = input.split(",")[1];
            byte[] decodedByte = android.util.Base64.decode(input, android.util.Base64.DEFAULT);
            return BitmapFactory.decodeByteArray(decodedByte, 0, decodedByte.length);
        } catch (Exception e) {
            return null;
        }
    }

    // ════════════════════════════════════════════════════════════
    // MENU CARD
    // ════════════════════════════════════════════════════════════
    private void toggleMenu() {
        if (menuVisible)
            hideMenu();
        else
            showMenu();
    }

    private boolean isMenuBeingRecreated = false;

    private void showMenu() {
        fabView.setVisibility(View.GONE);
        if (menuView != null) {
            try {
                wm.removeView(menuView);
            } catch (Exception ignored) {
            }
        }

        menuView = buildMenuCard();
        menuParams = overlayParams(dp(600 * SCALE), dp(400 * SCALE));
        menuParams.gravity = Gravity.TOP | Gravity.START;
        menuParams.x = fabParams.x - dp(20 * SCALE);
        menuParams.y = fabParams.y - dp(15 * SCALE);
        menuParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;

        // Đảm bảo menu có thể nhận sự kiện touch
        menuParams.flags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;

        // Thêm menu vào WindowManager
        wm.addView(menuView, menuParams);

        // Đảm bảo load đúng panel hiện tại
        // Cần đợi layout hoàn tất trước khi load panel
        menuView.post(() -> {
            if (contentHost != null && curTab >= 0 && curTab < 5) {
                loadPanel(curTab);
            }
        });

        menuVisible = true;
    }

    private void hideMenu() {
        if (menuView != null) {
            try {
                wm.removeView(menuView);
            } catch (Exception ignored) {
            }
            menuView = null;
        }
        menuVisible = false;
    }

    private LinearLayout buildMenuCard() {
        LinearLayout card = vBox();
        GradientDrawable cBg = new GradientDrawable();
        cBg.setCornerRadius(dp(20 * SCALE));
        cBg.setColor(C_SURF);
        cBg.setStroke(dp(1 * SCALE), 0x33FFFFFF);
        card.setBackground(cBg);
        card.setClipToOutline(true);
        if (Build.VERSION.SDK_INT >= 21)
            card.setElevation(dp(20 * SCALE));

        LinearLayout header = buildHeader();
        card.addView(header, new LinearLayout.LayoutParams(MP, dp(64 * SCALE)));

        // Red Accent Divider below header
        View line = new View(this);
        GradientDrawable lg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[] { 0x00FF3131, C_RED, 0x00FF3131 });
        line.setBackground(lg);
        card.addView(line, new LinearLayout.LayoutParams(MP, dp(1.5f * SCALE)));

        header.setOnTouchListener(new DragTouchListener() {
            @Override
            protected WindowManager.LayoutParams getParams() {
                return menuParams;
            }

            @Override
            protected View getRootView() {
                return menuView;
            }

            @Override
            protected void onClick() {
            }
        });

        // Body without sidebar
        LinearLayout body = vBox();

        // KROOT TITLE SECTION
        body.addView(buildTitleSection("POWER CHEATS", "Active"));

        contentHost = new FrameLayout(this);
        body.addView(contentHost, new LinearLayout.LayoutParams(MP, 0, 1f));
        card.addView(body, new LinearLayout.LayoutParams(MP, 0, 1f));

        return card;
    }

    private void collapseToFab() {
        if (logoView == null || menuView == null) {
            hideMenu();
            return;
        }
        int[] logoLoc = new int[2], menuLoc = new int[2];
        logoView.getLocationOnScreen(logoLoc);
        menuView.getLocationOnScreen(menuLoc);
        fabParams.x = menuParams.x + (logoLoc[0] - menuLoc[0]);
        fabParams.y = menuParams.y + (logoLoc[1] - menuLoc[1]);
        try {
            wm.updateViewLayout(fabView, fabParams);
        } catch (Exception ignored) {
        }
        hideMenu();
        fabView.setVisibility(View.VISIBLE);
    }

    // ════════════════════════════════════════════════════════════
    // HEADER
    // ════════════════════════════════════════════════════════════
    private LinearLayout buildHeader() {
        LinearLayout h = hBox();
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(12 * SCALE), 0, dp(12 * SCALE), 0);
        h.setBackgroundColor(0xFF000000); // Fully black header

        // App Icon Placeholder (Rounded Square)
        View logo;
        if (!ICON_IMAGE.isEmpty()) {
            ImageView iv = new ImageView(this);
            Bitmap b = decodeBase64(ICON_IMAGE);
            if (b != null) {
                iv.setImageBitmap(b);
                iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                int p = dp(6 * SCALE);
                iv.setPadding(p, p, p, p);
                logo = iv;
            } else {
                logo = new View(this);
            }
        } else {
            logo = new View(this);
        }

        logo.setBackgroundColor(Color.TRANSPARENT);
        h.addView(logo, dp(44 * SCALE), dp(44 * SCALE));

        // We still need logoView for the collapse animation logic
        logoView = new TextView(this);
        logoView.setVisibility(View.GONE);
        h.addView(logoView, 0, 0);

        h.addView(hGap((int) (16 * SCALE)));

        // Navigation Center
        LinearLayout nav = hBox();
        nav.setGravity(Gravity.CENTER);
        // Symbols: [◎ ESP] [⌖ AIM] [⚙ SETTINGS] (Bigger and technical style)
        String[] icons = { "◎", "⌖", "⚙" };
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            int color = (curTab == idx) ? C_RED : 0x4DFF3131;
            TextView iconView = tv(icons[i], 32 * SCALE, color, Typeface.NORMAL);
            iconView.setGravity(Gravity.CENTER);
            iconView.setPadding(dp(24 * SCALE), 0, dp(24 * SCALE), 0);
            iconView.setOnClickListener(v -> switchTab(idx));
            nav.addView(iconView);
        }
        h.addView(nav, new LinearLayout.LayoutParams(0, MP, 1f));

        // Bold Red Close Button
        TextView close = tv("✖", 24 * SCALE, C_RED, Typeface.BOLD);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(v -> collapseToFab());
        h.addView(close, dp(44 * SCALE), dp(44 * SCALE));

        return h;
    }

    private LinearLayout buildTitleSection(String title, String status) {
        LinearLayout v = vBox();
        v.setPadding(dp(20 * SCALE), dp(16 * SCALE), dp(20 * SCALE), dp(8 * SCALE));

        LinearLayout top = hBox();
        top.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout left = vBox();
        left.addView(tv(title, 16 * SCALE, C_RED, Typeface.BOLD));
        left.addView(tv(status, 12 * SCALE, C_WHITE, Typeface.NORMAL));
        top.addView(left, new LinearLayout.LayoutParams(0, WP, 1f));

        // Real-time Clock (IST)
        LinearLayout timeBox = hBox();
        timeBox.setBackground(createRect(dp(4), 0xFF1A1A1A));
        timeBox.setPadding(dp(10 * SCALE), dp(6 * SCALE), dp(10 * SCALE), dp(6 * SCALE));
        
        final TextView clockTv = tv("00:00:00", 14 * SCALE, C_WHITE, Typeface.BOLD);
        timeBox.addView(clockTv);
        top.addView(timeBox);

        // Update clock every second
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.ENGLISH);
                    sdf.setTimeZone(java.util.TimeZone.getTimeZone("GMT+5:30"));
                    clockTv.setText(sdf.format(new java.util.Date()));
                    handler.postDelayed(this, 1000);
                } catch (Exception e) {}
            }
        });

        v.addView(top);
        return v;
    }

    private GradientDrawable createRect(int radius, int color) {
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(radius);
        d.setColor(color);
        return d;
    }

    private TextView badge(String t, int tc, int bgC, int bc) {
        TextView v = tv(t, 14 * SCALE, tc, Typeface.BOLD);
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(dp(40 * SCALE));
        d.setColor(bgC);
        d.setStroke(dp(1 * SCALE), bc);
        v.setBackground(d);
        v.setPadding(dp(12 * SCALE), dp(6 * SCALE), dp(12 * SCALE), dp(6 * SCALE));
        return v;
    }

    private void switchTab(int idx) {
        if (idx == curTab)
            return;
        curTab = idx;

        // Refresh Menu to update Header Icon colors
        if (menuView != null) {
            wm.removeView(menuView);
            showMenu();
        }
    }

    private void loadPanel(int idx) {
        if (contentHost == null)
            return;
        contentHost.removeAllViews();
        LinearLayout panel;
        switch (idx) {
            case 0: // ALL ESP (Player + Visual)
                panel = vBox();
                panel.addView(panelPlayer());
                panel.addView(panelVisual());
                break;
            case 1:
                panel = panelAimbot();
                break;
            case 2:
                panel = panelConfig();
                break;
            default:
                panel = panelAimbot();
                break;
        }
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        panel.setLayoutParams(new LinearLayout.LayoutParams(MP, WP));
        sv.addView(panel);
        contentHost.addView(sv, new FrameLayout.LayoutParams(MP, MP));
    }

    private LinearLayout segmentedControl(String title, String[] items, int currentIdx, int featId) {
        LinearLayout v = vBox();
        v.setPadding(0, dp(8 * SCALE), 0, dp(16 * SCALE));

        if (title != null && !title.isEmpty()) {
            v.addView(tv(title, 14 * SCALE, C_MUT, Typeface.BOLD));
            v.addView(vGap(dp(8 * SCALE)));
        }

        LinearLayout row = hBox();
        row.setBackground(createRect(dp(8 * SCALE), 0xFF141414));
        row.setPadding(dp(2 * SCALE), dp(2 * SCALE), dp(2 * SCALE), dp(2 * SCALE));

        for (int i = 0; i < items.length; i++) {
            final int idx = i;
            TextView btn = tv(items[i], 13 * SCALE, i == currentIdx ? C_WHITE : C_MUT, Typeface.BOLD);
            btn.setGravity(Gravity.CENTER);
            btn.setPadding(0, dp(12 * SCALE), 0, dp(12 * SCALE));

            if (i == currentIdx) {
                btn.setBackground(createRect(dp(8 * SCALE), 0xFF2A2A2A));
            }

            btn.setOnClickListener(v1 -> {
                Changes(null, featId, title, idx, 0, 0, false, items[idx]);
                loadPanel(curTab); // Refresh panel
            });

            row.addView(btn, new LinearLayout.LayoutParams(0, WP, 1f));
        }

        v.addView(row);
        return v;
    }

    // ════════════════════════════════════════════════════════════
    // PANELS
    // ════════════════════════════════════════════════════════════
    private String getPanelFeatures(String panelName) {
        String list = getFeatureList();
        String[] lines = list.split("\n");
        StringBuilder result = new StringBuilder();
        boolean reading = false;
        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty())
                continue;
            if (line.equalsIgnoreCase(panelName)) {
                reading = true;
                continue;
            }
            if (reading && !line.contains("_"))
                break;
            if (reading)
                result.append(line).append("\n");
        }
        return result.toString();
    }

    private boolean defaultsLoaded = false;

    private void loadDefaultValues() {
        if (defaultsLoaded)
            return;
        String data = getFeatureList();
        String[] lines = data.split("\n");
        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty())
                continue;
            String[] parts = line.split("_");
            switch (parts[0]) {
                case "TOGGLE": {
                    int id = Integer.parseInt(parts[2]);
                    boolean state = parts[3].equalsIgnoreCase("True");
                    Changes(null, id, parts[1], 0, 0f, 0L, state, "");
                    break;
                }
                case "SLIDER": {
                    int id = Integer.parseInt(parts[2]);
                    int def = Integer.parseInt(parts[5]);
                    Changes(null, id, parts[1], def, 0f, 0L, false, "");
                    break;
                }
                case "SLIDERF": {
                    int id = Integer.parseInt(parts[2]);
                    float def = Float.parseFloat(parts[5]);
                    Changes(null, id, parts[1], (int) def, def, 0L, false, "");
                    break;
                }
                case "COMBO": {
                    int id = Integer.parseInt(parts[2]);
                    int def = Integer.parseInt(parts[4]);
                    Changes(null, id, parts[1], def, 0f, 0L, false, "");
                    break;
                }
            }
        }
        defaultsLoaded = true;
    }

    private LinearLayout buildPanel(String tab) {
        loadDefaultValues();
        LinearLayout p = pw();
        String data = getPanelFeatures(tab);
        String[] lines = data.split("\n");

        ArrayList<int[]> ids = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>();
        ArrayList<Boolean> isVipFeatures = new ArrayList<>();

        Runnable flushGrid = () -> {
            if (!ids.isEmpty()) {
                int[][] arr = new int[ids.size()][2];
                String[] n = new String[names.size()];
                boolean[] vipStatus = new boolean[isVipFeatures.size()];
                for (int i = 0; i < ids.size(); i++) {
                    arr[i] = ids.get(i);
                    n[i] = names.get(i);
                    vipStatus[i] = isVipFeatures.get(i);
                }
                p.addView(grid2(arr, n, vipStatus));
                ids.clear();
                names.clear();
                isVipFeatures.clear();
            }
        };

        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty())
                continue;
            String[] parts = line.split("_");
            switch (parts[0]) {
                case "SH":
                    flushGrid.run();
                    p.addView(sh(parts[1]));
                    break;
                case "INFO": {
                    flushGrid.run();
                    int color = C_WHITE;
                    String last = parts[parts.length - 1];
                    if (parts.length >= 4 && last.equalsIgnoreCase("GREEN"))
                        color = C_GREEN;
                    else if (parts.length >= 4 && last.equalsIgnoreCase("YELLOW"))
                        color = C_YELLOW;
                    StringBuilder value = new StringBuilder();
                    for (int i = 2; i < parts.length - 1; i++) {
                        if (i > 2)
                            value.append("_");
                        value.append(parts[i]);
                    }
                    p.addView(infoRow(parts[1], value.toString(), color));
                    break;
                }
                case "SLIDER": {
                    flushGrid.run();
                    p.addView(slider(parts[1],
                            Integer.parseInt(parts[2]),
                            Integer.parseInt(parts[3]),
                            Integer.parseInt(parts[4]),
                            Integer.parseInt(parts[5]),
                            parts[6]));
                    break;
                }
                case "SLIDERF": {
                    flushGrid.run();
                    p.addView(sliderFloat(parts[1],
                            Integer.parseInt(parts[2]),
                            Float.parseFloat(parts[3]),
                            Float.parseFloat(parts[4]),
                            Float.parseFloat(parts[5]),
                            parts[6]));
                    break;
                }
                case "COMBO": {
                    flushGrid.run();
                    p.addView(combo(parts[1],
                            Integer.parseInt(parts[2]),
                            parts[3].split(","),
                            Integer.parseInt(parts[4])));
                    break;
                }
                case "TOGGLE": {
                    boolean isVip = parts.length > 4 && parts[4].equalsIgnoreCase("VIP");
                    ids.add(new int[] {
                            Integer.parseInt(parts[2]),
                            parts[3].equalsIgnoreCase("True") ? 1 : 0 });
                    names.add(parts[1]);
                    isVipFeatures.add(isVip);
                    break;
                }
            }
        }
        flushGrid.run();
        return p;
    }

    private LinearLayout panelPlayer() {
        return buildPanel("PlayerPanel");
    }

    private LinearLayout panelVisual() {
        return buildPanel("panelVisual");
    }

    private LinearLayout panelAimbot() {
        return buildPanel("panelAimbot");
    }

    private LinearLayout panelMisc() {
        return buildPanel("panelMisc");
    }

    private LinearLayout panelConfig() {
        return buildPanel("panelConfig");
    }

    // ════════════════════════════════════════════════════════════
    // FOOTER
    // ════════════════════════════════════════════════════════════
    private LinearLayout buildFooter() {
        LinearLayout f = hBox();
        f.setGravity(Gravity.CENTER_VERTICAL);
        f.setPadding(dp(8 * SCALE), 0, dp(24 * SCALE), 0);
        f.setBackgroundColor(0x4D000000);
        f.addView(fDot("External", C_GREEN));
        f.addView(hGap((int) (24 * SCALE)));
        f.addView(fDot("BYPASS ACTIVE", C_YELLOW));
        View sp = new View(this);
        f.addView(sp, new LinearLayout.LayoutParams(0, 1, 1f));
        f.addView(tv("N/A", 11 * SCALE, C_SEC, Typeface.BOLD));
        return f;
    }

    private LinearLayout fDot(String label, int color) {
        LinearLayout r = hBox();
        r.setGravity(Gravity.CENTER_VERTICAL);
        ImageView d = new ImageView(this);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(color);
        d.setBackground(gd);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(8 * SCALE), dp(8 * SCALE));
        lp.leftMargin = dp(15);
        lp.rightMargin = dp(3);
        r.addView(d, lp);
        ObjectAnimator blink = ObjectAnimator.ofFloat(d, "alpha", 1f, 0.2f, 1f);
        blink.setDuration(1500);
        blink.setRepeatCount(ValueAnimator.INFINITE);
        blink.start();
        r.addView(hGap((int) (6 * SCALE)));
        r.addView(tv(label, 14 * SCALE, C_MUT, Typeface.NORMAL));
        return r;
    }

    @SuppressLint("ObsoleteSdkInt")
    private LinearLayout sh(String title) {
        LinearLayout r = hBox();
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MP, WP);
        lp.setMargins(0, 0, 0, dp(13 * SCALE));
        r.setLayoutParams(lp);
        TextView t = tv(title, 15 * SCALE, C_RED, Typeface.BOLD);
        if (Build.VERSION.SDK_INT >= 21)
            t.setLetterSpacing(0.12f);
        r.addView(t);
        r.addView(hGap((int) (10 * SCALE)));
        View line = new View(this);
        GradientDrawable lg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[] { C_RED_D, 0x00000000 });
        line.setBackground(lg);
        r.addView(line, new LinearLayout.LayoutParams(0, dp(1 * SCALE), 1f));
        return r;
    }

    private View vGap(int height) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, height));
        return v;
    }

    // ════════════════════════════════════════════════════════════
    // VIP DIALOG
    // ════════════════════════════════════════════════════════════
    private View dialogView;

    private void showVipRequiredDialog(String featureName) {
        LinearLayout dialogLayout = vBox();
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(16 * SCALE));
        bg.setColor(C_SURF);
        bg.setStroke(dp(1 * SCALE), C_RED);
        dialogLayout.setBackground(bg);
        dialogLayout.setPadding(dp(24 * SCALE), dp(24 * SCALE), dp(24 * SCALE), dp(24 * SCALE));

        TextView titleView = tv("👑 VIP Feature", 18 * SCALE, C_YELLOW, Typeface.BOLD);
        titleView.setGravity(Gravity.CENTER);
        dialogLayout.addView(titleView);
        dialogLayout.addView(divH());
        dialogLayout.addView(vGap(dp(8 * SCALE)));

        TextView msgView = tv(
                featureName + " is a VIP-only feature.\n\nUpgrade to VIP to unlock this powerful feature!",
                14 * SCALE, C_WHITE, Typeface.NORMAL);
        msgView.setGravity(Gravity.CENTER);
        dialogLayout.addView(msgView);
        dialogLayout.addView(vGap(dp(16 * SCALE)));

        LinearLayout buttonRow = hBox();
        buttonRow.setGravity(Gravity.CENTER);

        TextView laterBtn = btnOutline("LATER");
        laterBtn.setOnClickListener(v -> {
            if (dialogView != null)
                try {
                    wm.removeView(dialogView);
                } catch (Exception ignored) {
                }
        });

        TextView upgradeBtn = btnPrimary("UPGRADE");
        upgradeBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("https://your-upgrade-link.com"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            if (dialogView != null)
                try {
                    wm.removeView(dialogView);
                } catch (Exception ignored) {
                }
        });

        buttonRow.addView(laterBtn);
        buttonRow.addView(hGap(dp(16 * SCALE)));
        buttonRow.addView(upgradeBtn);
        dialogLayout.addView(buttonRow);

        // ── Dialog params — numeric type, tránh lỗi touch ──
        int iparams = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? 2038 : 2002;

        WindowManager.LayoutParams dialogParams = new WindowManager.LayoutParams(
                dp(300 * SCALE),
                WindowManager.LayoutParams.WRAP_CONTENT,
                iparams,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
                -3);

        dialogParams.gravity = Gravity.CENTER;
        dialogView = dialogLayout;

        try {
            wm.addView(dialogView, dialogParams);
            dialogView.postDelayed(() -> {
                if (dialogView != null) {
                    try {
                        wm.removeView(dialogView);
                        dialogView = null;
                    } catch (Exception ignored) {
                    }
                }
            }, 5000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public native static boolean CheckVip();

    // ════════════════════════════════════════════════════════════
    // TOGGLE WIDGET
    // ════════════════════════════════════════════════════════════
    private LinearLayout toggle(String label, int featureIdx, boolean on0, boolean isVipOnly) {
        boolean isVip = true; // Bypassed VIP check
        boolean canEnable = true; // All features now enabled

        FeatureState savedState = featureStates.get(featureIdx);
        boolean initialState = (savedState != null) ? savedState.enabled : on0;
        if (!canEnable && initialState)
            initialState = false;

        LinearLayout v = vBox();
        v.setPadding(0, dp(8 * SCALE), 0, dp(8 * SCALE));

        v.addView(tv(label, 14 * SCALE, C_MUT, Typeface.BOLD));
        v.addView(vGap(dp(8 * SCALE)));

        LinearLayout row = hBox();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16 * SCALE), dp(12 * SCALE), dp(16 * SCALE), dp(12 * SCALE));
        row.setBackground(createRect(dp(12 * SCALE), 0xFF141414));

        TextView lv = tv(label, 14 * SCALE, initialState ? C_WHITE : C_SEC, Typeface.BOLD);
        lv.setSingleLine(true);
        row.addView(lv, new LinearLayout.LayoutParams(0, WP, 1f));

        FrameLayout track = new FrameLayout(this);
        GradientDrawable trackD = new GradientDrawable();
        trackD.setCornerRadius(dp(40 * SCALE));
        trackD.setColor(initialState ? C_RED : 0xFF2A2A2A);
        track.setBackground(trackD);
        track.setLayoutParams(new LinearLayout.LayoutParams(dp(44 * SCALE), dp(24 * SCALE)));

        View thumb = new View(this);
        GradientDrawable thumbD = new GradientDrawable();
        thumbD.setShape(GradientDrawable.OVAL);
        thumbD.setColor(initialState ? 0xFF141414 : C_WHITE);
        thumb.setBackground(thumbD);

        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(dp(18 * SCALE), dp(18 * SCALE));
        tlp.gravity = Gravity.CENTER_VERTICAL;
        tlp.leftMargin = initialState ? dp(22 * SCALE) : dp(4 * SCALE);
        thumb.setLayoutParams(tlp);
        track.addView(thumb);

        row.addView(track);

        /*
         * if (isVipOnly && !isVip) {
         * row.setAlpha(0.5f);
         * row.addView(hGap(dp(8 * SCALE)));
         * row.addView(tv("👑", 14 * SCALE, C_YELLOW, Typeface.BOLD));
         * }
         */

        row.setTag(new Object[] {
                trackD, thumbD, tlp, thumb, lv,
                featureIdx, initialState, canEnable, isVipOnly });

        row.setOnClickListener(v1 -> {
            Object[] tag = (Object[]) row.getTag();
            boolean featureCanEnable = (boolean) tag[7];
            boolean isVipFeature = (boolean) tag[8];

            if (!featureCanEnable) {
                if (isVipFeature)
                    showVipRequiredDialog(label);
                return;
            }

            GradientDrawable tD = (GradientDrawable) tag[0];
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) tag[2];
            View th = (View) tag[3];
            TextView labelView = (TextView) tag[4];
            int feat = (int) tag[5];
            boolean state = !(boolean) tag[6];
            tag[6] = state;

            tD.setColor(state ? C_RED : 0xFF2A2A2A);
            thumbD.setColor(state ? 0xFF141414 : C_WHITE);
            params.leftMargin = state ? dp(22 * SCALE) : dp(4 * SCALE);
            th.setLayoutParams(params);
            labelView.setTextColor(state ? C_WHITE : C_SEC);

            FeatureState fs = featureStates.get(feat);
            if (fs == null)
                fs = new FeatureState(feat, label, state);
            else
                fs.enabled = state;
            featureStates.put(feat, fs);

            Changes(null, feat, labelView.getText().toString(), 0, 0f, 0, state, "");
        });
        v.addView(row);
        return v;
    }

    private void applyTBg(LinearLayout r, boolean on) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12 * SCALE));
        bg.setColor(on ? 0x1AFF4B4B : 0x05FFFFFF);
        bg.setStroke(dp(1 * SCALE), on ? 0x4DFF4B4B : 0x14FF4B4B);
        r.setBackground(bg);
    }

    private GridLayout grid2(int[][] items, String[] names, boolean[] isVip) {
        GridLayout g = new GridLayout(this);
        g.setColumnCount(2);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MP, WP);
        lp.setMargins(0, 0, 0, dp(16 * SCALE));
        g.setLayoutParams(lp);
        for (int i = 0; i < items.length; i++) {
            int c = i % 2, row = i / 2;
            GridLayout.LayoutParams cp = new GridLayout.LayoutParams(
                    GridLayout.spec(row), GridLayout.spec(c, 1f));
            cp.width = 0;
            cp.height = WP;
            cp.setMargins(c == 1 ? dp(4 * SCALE) : 0,
                    row > 0 ? dp(8 * SCALE) : 0,
                    c == 0 ? dp(4 * SCALE) : 0, 0);
            g.addView(toggle(names[i], items[i][0], items[i][1] == 1, isVip[i]), cp);
        }
        return g;
    }

    // ════════════════════════════════════════════════════════════
    // SLIDERS
    // ════════════════════════════════════════════════════════════
    private LinearLayout sliderFloat(String title, int feat,
            float min, float max, float def, String sfx) {
        FeatureState savedState = featureStates.get(feat);
        float initialValue = (savedState != null) ? savedState.floatValue : def;
        final float scale = 100f;

        LinearLayout g = vBox();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MP, WP);
        lp.setMargins(0, 0, 0, dp(18 * SCALE));
        g.setLayoutParams(lp);

        LinearLayout hdr = hBox();
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(MP, WP);
        hlp.setMargins(0, 0, 0, dp(6 * SCALE));
        hdr.setLayoutParams(hlp);
        hdr.addView(tv(title, 14 * SCALE, C_MUT, Typeface.BOLD),
                new LinearLayout.LayoutParams(0, WP, 1f));
        final TextView valV = tv(String.format("%.2f%s", initialValue, sfx), 13 * SCALE, C_RED, Typeface.BOLD);
        hdr.addView(valV);
        g.addView(hdr);

        SeekBar sb = new SeekBar(this);
        sb.setMax((int) ((max - min) * scale));
        sb.setProgress((int) ((initialValue - min) * scale));
        if (Build.VERSION.SDK_INT >= 21) {
            sb.getThumb().setColorFilter(C_RED, PorterDuff.Mode.SRC_IN);
            sb.getProgressDrawable().setColorFilter(C_RED, PorterDuff.Mode.SRC_IN);
        }
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                float real = min + ((float) progress / scale);
                valV.setText(String.format("%.2f%s", real, sfx));
                FeatureState fs = featureStates.get(feat);
                if (fs == null)
                    fs = new FeatureState(feat, title, false);
                fs.floatValue = real;
                featureStates.put(feat, fs);
                Changes(null, feat, title, (int) real, real, 0L, false, "");
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        g.addView(sb, new LinearLayout.LayoutParams(MP, WP));
        return g;
    }

    private LinearLayout slider(String title, int feat,
            int min, int max, int def, String sfx) {
        FeatureState savedState = featureStates.get(feat);
        int initialValue = (savedState != null) ? savedState.intValue : def;

        LinearLayout g = vBox();
        g.setPadding(0, dp(8 * SCALE), 0, dp(18 * SCALE));

        LinearLayout hdr = hBox();
        hdr.setGravity(Gravity.CENTER_VERTICAL);
        hdr.addView(tv(title, 14 * SCALE, C_WHITE, Typeface.BOLD),
                new LinearLayout.LayoutParams(0, WP, 1f));
        final TextView valV = tv(initialValue + sfx, 13 * SCALE, C_RED, Typeface.BOLD);
        hdr.addView(valV);
        g.addView(hdr);
        g.addView(vGap(dp(8 * SCALE)));

        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(initialValue - min);

        if (Build.VERSION.SDK_INT >= 21) {
            sb.getThumb().setColorFilter(C_WHITE, PorterDuff.Mode.SRC_IN);
            LayerDrawable ld = (LayerDrawable) sb.getProgressDrawable();
            ld.setColorFilter(C_RED, PorterDuff.Mode.SRC_IN);
        }
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int real = progress + min;
                valV.setText(real + sfx);
                FeatureState fs = featureStates.get(feat);
                if (fs == null)
                    fs = new FeatureState(feat, title, false);
                fs.intValue = real;
                featureStates.put(feat, fs);
                Changes(null, feat, title, real, 0, 0, false, "");
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        g.addView(sb, new LinearLayout.LayoutParams(MP, WP));
        return g;
    }

    // ════════════════════════════════════════════════════════════
    // COMBO / SPINNER
    // ════════════════════════════════════════════════════════════
    private LinearLayout combo(String label, int feat, String[] opts, int def) {
        FeatureState savedState = featureStates.get(feat);
        int initialSelection = (savedState != null) ? savedState.intValue : def;

        LinearLayout w = vBox();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MP, WP);
        lp.setMargins(0, 0, 0, dp(18 * SCALE));
        w.setLayoutParams(lp);

        TextView lv = tv(label, 14 * SCALE, C_MUT, Typeface.BOLD);
        LinearLayout.LayoutParams lvlp = new LinearLayout.LayoutParams(MP, WP);
        lvlp.setMargins(0, 0, 0, dp(6 * SCALE));
        lv.setLayoutParams(lvlp);
        w.addView(lv);

        final Spinner sp = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(
                this, android.R.layout.simple_spinner_item, opts) {
            @Override
            public View getView(int p, View cv, ViewGroup parent) {
                TextView v = (TextView) super.getView(p, cv, parent);
                v.setTextColor(C_WHITE);
                v.setTextSize(14 * SCALE);
                v.setBackgroundColor(Color.TRANSPARENT);
                return v;
            }

            @Override
            public View getDropDownView(int p, View cv, ViewGroup parent) {
                TextView v = (TextView) super.getDropDownView(p, cv, parent);
                v.setBackgroundColor(0xFF191D2B);
                v.setTextColor(C_WHITE);
                v.setTextSize(14 * SCALE);
                v.setPadding(dp(14 * SCALE), dp(10 * SCALE), dp(14 * SCALE), dp(10 * SCALE));
                return v;
            }
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                    int position, long id) {
                FeatureState fs = featureStates.get(feat);
                if (fs == null)
                    fs = new FeatureState(feat, label, false);
                fs.intValue = position;
                fs.stringValue = opts[position];
                featureStates.put(feat, fs);
                Changes(null, feat, label, position, 0, 0, false, opts[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        sp.post(() -> sp.setSelection(initialSelection, false));
        sp.setPadding(dp(14 * SCALE), dp(8 * SCALE), dp(14 * SCALE), dp(8 * SCALE));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(12 * SCALE));
        bg.setColor(0xFF191D2B);
        bg.setStroke(dp(1 * SCALE), 0xFF2A2F40);

        Drawable arrow = getResources().getDrawable(android.R.drawable.arrow_down_float);
        arrow.setColorFilter(C_MUT, PorterDuff.Mode.SRC_IN);
        LayerDrawable layer = new LayerDrawable(new Drawable[] { bg, arrow });
        layer.setLayerGravity(1, Gravity.END | Gravity.CENTER_VERTICAL);
        layer.setLayerInset(1, 0, 0, dp(10 * SCALE), 0);
        sp.setBackground(layer);

        w.addView(sp, new LinearLayout.LayoutParams(MP, WP));
        return w;
    }

    private LinearLayout infoRow(String key, String val, int vc) {
        LinearLayout outer = vBox();
        LinearLayout row = hBox();
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(8 * SCALE), 0, dp(8 * SCALE));
        TextView kv = tv(key, 14 * SCALE, C_MUT, Typeface.NORMAL);
        kv.setLayoutParams(new LinearLayout.LayoutParams(dp(100 * SCALE), WP));
        row.addView(kv);
        row.addView(tv(val, 14 * SCALE, vc, Typeface.NORMAL));
        outer.addView(row);
        View div = new View(this);
        div.setBackgroundColor(0x0AFFFFFF);
        outer.addView(div, new LinearLayout.LayoutParams(MP, dp(1 * SCALE)));
        return outer;
    }

    private TextView btnPrimary(String t) {
        TextView v = tv(t, 12 * SCALE, C_WHITE, Typeface.BOLD);
        v.setPadding(dp(18 * SCALE), dp(8 * SCALE), dp(18 * SCALE), dp(8 * SCALE));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(40 * SCALE));
        bg.setColor(C_RED);
        v.setBackground(bg);
        return v;
    }

    private TextView btnOutline(String t) {
        TextView v = tv(t, 12 * SCALE, C_SEC, Typeface.BOLD);
        v.setPadding(dp(18 * SCALE), dp(8 * SCALE), dp(18 * SCALE), dp(8 * SCALE));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(40 * SCALE));
        bg.setColor(0x05FFFFFF);
        bg.setStroke(dp(1 * SCALE), 0xFF2F354A);
        v.setBackground(bg);
        return v;
    }

    // ════════════════════════════════════════════════════════════
    // DRAG HELPER
    // ════════════════════════════════════════════════════════════
    private abstract class DragTouchListener implements View.OnTouchListener {
        private int startRawX, startRawY, origX, origY;
        private long downTime;
        private boolean dragging;

        protected abstract WindowManager.LayoutParams getParams();

        protected abstract View getRootView();

        protected abstract void onClick();

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startRawX = (int) e.getRawX();
                    startRawY = (int) e.getRawY();
                    origX = getParams().x;
                    origY = getParams().y;
                    downTime = System.currentTimeMillis();
                    dragging = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) e.getRawX() - startRawX;
                    int dy = (int) e.getRawY() - startRawY;
                    if (!dragging &&
                            (Math.abs(dx) > dp(4 * SCALE) || Math.abs(dy) > dp(4 * SCALE)))
                        dragging = true;
                    if (dragging) {
                        WindowManager.LayoutParams p = getParams();
                        p.x = origX + dx;
                        p.y = origY + dy;
                        try {
                            wm.updateViewLayout(getRootView(), p);
                        } catch (Exception ignored) {
                        }
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!dragging && System.currentTimeMillis() - downTime < 300)
                        onClick();
                    return true;
            }
            return false;
        }
    }

    // ════════════════════════════════════════════════════════════
    // WindowManager params helper
    // Dùng numeric type (2038/2002) thay vì constant để tránh
    // lỗi touch không nhấn được app bên dưới trên một số ROM
    // ════════════════════════════════════════════════════════════
    private WindowManager.LayoutParams overlayParams(int w, int h) {
        int iparams = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? 2038 : 2002;

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                iparams,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
                -3); // -3 == PixelFormat.TRANSLUCENT

        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    // ════════════════════════════════════════════════════════════
    // MICRO HELPERS
    // ════════════════════════════════════════════════════════════
    private LinearLayout pw() {
        LinearLayout p = vBox();
        p.setPadding(dp(20 * SCALE), dp(20 * SCALE), dp(20 * SCALE), dp(20 * SCALE));
        return p;
    }

    private LinearLayout hBox() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        return v;
    }

    private LinearLayout vBox() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private TextView tv(String t, float sp, int c, int s) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(c);
        v.setTextSize(sp);
        v.setTypeface(null, s);
        return v;
    }

    private View hGap(int d) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(d), 1));
        return v;
    }

    private View divH() {
        View v = new View(this);
        v.setBackgroundColor(C_BORDER);
        v.setLayoutParams(new LinearLayout.LayoutParams(MP, dp(1 * SCALE)));
        return v;
    }

    private View divV() {
        View v = new View(this);
        v.setBackgroundColor(C_BORDER);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(1 * SCALE), MP));
        return v;
    }

    public int dp(float v) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (v * density + 0.5f);
    }
}