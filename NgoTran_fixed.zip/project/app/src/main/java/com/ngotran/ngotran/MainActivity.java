package com.ngotran.ngotran;

import android.animation.*;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences.Editor;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.text.method.PasswordTransformationMethod;
import android.view.*;
import android.view.animation.*;
import android.widget.*;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Random;

public class MainActivity extends Activity {
    // NgoTranAJDHAID
    // ── Palette ──────────────────────────────────────────────────
    private static final int C_BG = 0xFF0A0A0A;
    private static final int C_CARD = 0xFF121212;
    private static final int C_RED = 0xFFFF0000;
    private static final int C_RED_D = 0xFF880000;
    private static final int C_WHITE = 0xFFFFFFFF;
    private static final int C_DIM = 0xFF888888;
    private static final int C_IN_BG = 0xFF1C1C1C;
    private static final int C_BORDER = 0xFFFF0000;
    private static final int C_BLUE = 0xFF24A1DE;
    private static final int C_SUCCESS = 0xFF44EE88;

    private static final int MP = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int REQ = 101;

    // ── SharedPreferences ────────────────────────────────────────
    private static final String PREFS_NAME = "PowerPrefs";
    private static final String KEY_SAVED = "saved_key";
    private static final String KEY_IS_VALIDATED = "key_validated";
    private static final String KEY_LAST_SUCCESS = "last_success_time";

    // ── View refs ─────────────────────────────────────────────────
    private LinearLayout cardView;
    private FrameLayout wrapKey;
    private EditText etKey;
    private FrameLayout btnSubmit;
    private TextView btnLabel;
    private TextView tvStatus;
    private ImageView saveIndicator;
    private boolean keyVisible = false;
    private boolean isReady = false;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    static {
        System.loadLibrary("power");
    }

    public static void copyPower(Context context) {

        String abi = android.os.Build.SUPPORTED_ABIS[0];

        String assetName;

        if (abi.contains("x86")) {
            assetName = "Power"; // emulator
        } else {
            assetName = "Power1"; // phone arm
        }

        String outPath = context.getCacheDir().getAbsolutePath() + "/Power";

        try {

            InputStream in = context.getAssets().open(assetName);
            File outFile = new File(outPath);

            FileOutputStream out = new FileOutputStream(outFile);

            byte[] buffer = new byte[4096];
            int read;

            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }

            in.close();
            out.flush();
            out.close();

            Runtime.getRuntime().exec("chmod 777 " + outPath);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // ════════════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        copyPower(this);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        hideUI();

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(C_BG);

        // 1. Animated BG
        root.addView(new CyberBg(this), new FrameLayout.LayoutParams(MP, MP));

        // 2. Card
        cardView = buildCard();
        FrameLayout.LayoutParams cLp = new FrameLayout.LayoutParams(dp(340), WP);
        cLp.gravity = Gravity.CENTER;
        root.addView(cardView, cLp);

        isReady = true;

        // 3. Watermark
        TextView wm = tv("Power External · Free Fire  |  v2.1", 9, 0xFF1E2138, Typeface.NORMAL);
        wm.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams wmLp = new FrameLayout.LayoutParams(MP, WP);
        wmLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        wmLp.bottomMargin = dp(14);
        root.addView(wm, wmLp);

        setContentView(root);

        // Entrance animation
        cardView.setAlpha(0f);
        cardView.setTranslationY(dp(55));
        ui.postDelayed(() -> {
            AnimatorSet set = new AnimatorSet();
            ObjectAnimator fade = ObjectAnimator.ofFloat(cardView, "alpha", 0f, 1f);
            ObjectAnimator slide = ObjectAnimator.ofFloat(cardView, "translationY", dp(55), 0f);
            fade.setDuration(500);
            slide.setDuration(500);
            slide.setInterpolator(new DecelerateInterpolator(2f));
            set.playTogether(fade, slide);
            set.start();
        }, 120);

        // Khôi phục key đã lưu
        String savedKey = prefs.getString(KEY_SAVED, "");
        if (!savedKey.isEmpty()) {
            etKey.setText(savedKey);
            etKey.setSelection(savedKey.length());
            if (prefs.getBoolean(KEY_IS_VALIDATED, false)) {
                ui.postDelayed(() -> doSubmit(true), 900);
            }
        }
    }

    private void saveKey(String key, boolean isValidated) {
        Editor editor = prefs.edit();
        editor.putString(KEY_SAVED, key);
        editor.putBoolean(KEY_IS_VALIDATED, isValidated);
        if (isValidated)
            editor.putLong(KEY_LAST_SUCCESS, System.currentTimeMillis());
        editor.apply();
        showSaveIndicator(isValidated);
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private void showSaveIndicator(boolean success) {
        if (!isReady || cardView.getParent() == null)
            return;

        if (saveIndicator == null) {
            saveIndicator = new ImageView(this);
            saveIndicator.setImageDrawable(
                    getResources().getDrawable(android.R.drawable.stat_sys_download_done));
            saveIndicator.setAlpha(0f);

            FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(24), dp(24));
            p.gravity = Gravity.END | Gravity.TOP;
            p.topMargin = dp(10);
            p.rightMargin = dp(10);
            ((FrameLayout) cardView.getParent()).addView(saveIndicator, p);
        }

        saveIndicator.setColorFilter(success ? C_SUCCESS : C_RED, PorterDuff.Mode.SRC_IN);
        saveIndicator.animate()
                .alpha(1f).setDuration(300)
                .withEndAction(
                        () -> ui.postDelayed(() -> saveIndicator.animate().alpha(0f).setDuration(500).start(), 1500))
                .start();
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private void clearSavedKey() {
        prefs.edit().remove(KEY_SAVED).remove(KEY_IS_VALIDATED).apply();
        if (saveIndicator != null && isReady) {
            saveIndicator.setImageDrawable(
                    getResources().getDrawable(android.R.drawable.stat_notify_error));
            showSaveIndicator(false);
        }
    }

    // ── System overrides ─────────────────────────────────────────

    @Override
    public void onWindowFocusChanged(boolean h) {
        super.onWindowFocusChanged(h);
        if (h)
            hideUI();
    }

    @SuppressLint("ObsoleteSdkInt")
    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        if (req == REQ) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                    && Settings.canDrawOverlays(this))
                launch(this);
            else
                status("Cần quyền hiển thị trên ứng dụng khác!", C_RED);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
    }

    // ── Build UI ─────────────────────────────────────────────────

    @SuppressLint("ObsoleteSdkInt")
    private LinearLayout buildCard() {
        LinearLayout card = vl();
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(24), dp(32), dp(24), dp(24));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(25));
        bg.setColor(C_CARD);
        bg.setStroke(dp(2), C_RED);
        card.setBackground(bg);

        if (Build.VERSION.SDK_INT >= 21)
            card.setElevation(dp(20));

        // Header Title
        TextView title = tv("POWER CHEATS", 22, C_RED, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(24));
        card.addView(title);

        // Key Input
        wrapKey = keyField();
        etKey = (EditText) wrapKey.getTag();
        card.addView(wrapKey);

        card.addView(gap(20));

        // Authenticate Button
        btnSubmit = submitButton();
        card.addView(btnSubmit);

        card.addView(gap(24));

        // Community Footer
        card.addView(bottomRow());

        // Status field (Invisible by default)
        tvStatus = tv("", 11, C_RED, Typeface.NORMAL);
        tvStatus.setGravity(Gravity.CENTER);
        tvStatus.setVisibility(View.INVISIBLE);
        LinearLayout.LayoutParams stLp = new LinearLayout.LayoutParams(MP, WP);
        stLp.setMargins(0, dp(10), 0, 0);
        card.addView(tvStatus, stLp);

        return card;
    }

    private FrameLayout keyField() {
        FrameLayout wrap = new FrameLayout(this);
        wrap.setLayoutParams(new LinearLayout.LayoutParams(MP, dp(55)));

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(15));
        bg.setColor(0xFF1A1A1A);
        wrap.setBackground(bg);

        EditText et = new EditText(this);
        et.setHint("XXXXX-XXXXX-XXXXX-XXXXX");
        et.setHintTextColor(0xFF555555);
        et.setTextColor(0xFFBBBBBB);
        et.setHighlightColor(0x44FF0000);
        et.setTextSize(13);
        et.setSingleLine(true);
        et.setBackground(null);
        et.setPadding(dp(20), 0, dp(60), 0);
        et.setGravity(Gravity.CENTER_VERTICAL);
        et.setTypeface(Typeface.MONOSPACE);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);

        et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {
            }

            @Override
            public void onTextChanged(CharSequence s, int st, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String key = s.toString().trim();
                if (!key.isEmpty())
                    saveKey(key, false);
                else
                    clearSavedKey();
            }
        });

        // Paste Icon Button
        LinearLayout pasteBtn = hBox();
        pasteBtn.setGravity(Gravity.CENTER);
        pasteBtn.setPadding(dp(10), 0, dp(15), 0);

        // Custom Programmatic Paste Icon
        View icon = new View(this) {
            @Override
            protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(C_RED);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(dp(1.5f));

                // Drawing 2 overlapping rectangles (clipboard look)
                float w = getWidth(), h = getHeight();
                float s = w * 0.4f;
                canvas.drawRoundRect(w * 0.2f, h * 0.2f, w * 0.2f + s, h * 0.2f + s, dp(2), dp(2), p);
                canvas.drawRoundRect(w * 0.4f, h * 0.4f, w * 0.4f + s, h * 0.4f + s, dp(2), dp(2), p);
            }
        };
        pasteBtn.addView(icon, new LinearLayout.LayoutParams(dp(24), dp(24)));

        pasteBtn.setOnClickListener(v -> {
            android.content.ClipboardManager cb = (android.content.ClipboardManager) getSystemService(
                    Context.CLIPBOARD_SERVICE);
            if (cb.hasPrimaryClip() && cb.getPrimaryClip().getItemCount() > 0) {
                String text = cb.getPrimaryClip().getItemAt(0).getText().toString();
                et.setText(text);
                status("Pasted from clipboard", C_WHITE);
            }
        });

        FrameLayout.LayoutParams pLp = new FrameLayout.LayoutParams(WP, MP);
        pLp.gravity = Gravity.END;

        // Add EditText FIRST, then Paste Button so it stays ON TOP
        wrap.addView(et, new FrameLayout.LayoutParams(MP, MP));
        wrap.addView(pasteBtn, pLp);

        wrap.setTag(et);
        return wrap;
    }

    private FrameLayout submitButton() {
        FrameLayout btn = new FrameLayout(this);
        btn.setLayoutParams(new LinearLayout.LayoutParams(MP, dp(58)));

        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(C_RED);
        btnBg.setCornerRadius(dp(15));
        btn.setBackground(btnBg);

        LinearLayout content = hBox();
        content.setGravity(Gravity.CENTER);

        btnLabel = tv("AUTHENTICATE", 15, C_WHITE, Typeface.BOLD);
        btnLabel.setLetterSpacing(0.05f);
        content.addView(btnLabel);

        btn.addView(content, new FrameLayout.LayoutParams(MP, MP));

        btn.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setAlpha(0.85f);
                    break;
                case MotionEvent.ACTION_UP:
                    v.setAlpha(1.0f);
                    v.postDelayed(() -> doSubmit(false), 50);
                    break;
                case MotionEvent.ACTION_CANCEL:
                    v.setAlpha(1.0f);
                    break;
            }
            return true;
        });

        return btn;
    }

    private LinearLayout bottomRow() {
        LinearLayout col = vl();
        col.setGravity(Gravity.CENTER_HORIZONTAL);

        col.addView(tv("Join Community", 13, 0xFF777777, Typeface.NORMAL));
        col.addView(gap(12));

        LinearLayout row = hBox();
        row.setGravity(Gravity.CENTER);

        row.addView(tgIcon("https://t.me/+jfT1Pv_T3h5jZjQ1"));
        row.addView(hBoxGap(16));
        row.addView(tgIcon("https://t.me/Powercheatsowner"));

        col.addView(row);
        return col;
    }

    private View tgIcon(String url) {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable d = new GradientDrawable();
        d.setCornerRadius(dp(13));
        d.setColor(C_BLUE);
        f.setBackground(d);
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(48)));

        View icon = new View(this) {
            @Override
            protected void onDraw(Canvas canvas) {
                super.onDraw(canvas);
                Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                p.setColor(Color.WHITE);
                p.setStyle(Paint.Style.FILL);

                float w = getWidth(), h = getHeight();
                canvas.translate(w * 0.1f, h * 0.1f);
                w *= 0.8f;
                h *= 0.8f;

                Path path = new Path();
                path.moveTo(w * 0.05f, h * 0.5f);
                path.lineTo(w * 0.95f, h * 0.05f);
                path.lineTo(w * 0.75f, h * 0.95f);
                path.lineTo(w * 0.45f, h * 0.7f);
                path.lineTo(w * 0.35f, h * 0.9f);
                path.lineTo(w * 0.32f, h * 0.65f);
                path.close();
                canvas.drawPath(path, p);

                // The small inner fold
                p.setColor(0xFFB0D9F0); // Subtle blue for depth
                Path fold = new Path();
                fold.moveTo(w * 0.32f, h * 0.65f);
                fold.lineTo(w * 0.55f, h * 0.52f);
                fold.lineTo(w * 0.45f, h * 0.7f);
                fold.close();
                canvas.drawPath(fold, p);
            }
        };

        FrameLayout.LayoutParams iLp = new FrameLayout.LayoutParams(dp(26), dp(26));
        iLp.gravity = Gravity.CENTER;
        f.addView(icon, iLp);

        f.setOnClickListener(v -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception e) {
            }
        });
        return f;
    }

    private View hBoxGap(int w) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(w), 1));
        return v;
    }

    // ── Submit / Validation ──────────────────────────────────────

    @SuppressLint({ "SetTextI18n", "ObsoleteSdkInt" })
    private void doSubmit(boolean isAutoLogin) {
        String key = etKey.getText().toString().trim();

        if (key.isEmpty()) {
            status("⚠  Nhập license key trước!", C_RED);
            shake(wrapKey);
            return;
        }

        if (!isAutoLogin) {
            btnLabel.setText("VERIFYING...");
            btnSubmit.setEnabled(false);
            status("Đang xác thực...", C_DIM);
        }

        new Thread(() -> {
            String result = null;
            try {
                result = isValid(key);
            } catch (Throwable e) {
                e.printStackTrace();
                final String errMsg = "Lỗi xác thực: " + e.getMessage();
                runOnUiThread(() -> {
                    status(errMsg, C_RED);
                    btnLabel.setText("ACTIVATE  →");
                    btnSubmit.setEnabled(true);
                });
                return;
            }

            final boolean valid = result != null && result.contains("success");
            final String finalResult = (result != null) ? (result.contains("{") ? "Đăng nhập thành công" : result)
                    : "Không có phản hồi";

            if (valid && result.startsWith("{")) {
                try {
                    JSONObject obj = new JSONObject(result);
                    String sName = obj.optString("seller_name", "Power");
                    String sType = obj.optString("seller_type", "Owner");
                    String exp = obj.optString("expire_date", "Unlimited");
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                            .putString("seller_name", sName)
                            .putString("seller_type", sType)
                            .putString("expire_date", exp)
                            .apply();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            runOnUiThread(() -> {
                if (valid) {
                    btnLabel.setText("✓  KEY HỢP LỆ");
                    status("✓  " + finalResult, C_SUCCESS);
                    flashSuccess();
                    saveKey(key, true);

                    ui.postDelayed(() -> {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                                && !Settings.canDrawOverlays(this)) {
                            status("Cần quyền hiển thị trên ứng dụng khác", C_DIM);
                            btnLabel.setText("CẤP QUYỀN");
                            btnSubmit.setEnabled(true);
                            startActivityForResult(
                                    new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:" + getPackageName())),
                                    REQ);
                        } else {
                            launch(this);
                        }
                    }, 750);

                } else {
                    if (!isAutoLogin) {
                        btnLabel.setText("ACTIVATE  →");
                        btnSubmit.setEnabled(true);
                        // ✅ Hiển thị lý do thất bại từ server
                        status("✗  " + finalResult, C_RED);
                        shake(wrapKey);
                        shake(btnSubmit);
                        prefs.edit().putBoolean(KEY_IS_VALIDATED, false).apply();
                    }
                }
            });
        }).start();
    }

    private native String isValid(String key);

    private void launch(Context context) {
        Intent i = new Intent(context, FloatingService.class);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            context.startForegroundService(i);
        else
            context.startService(i);

        if (context instanceof Activity) {
            Activity act = (Activity) context;
            act.overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            act.finish();
        }
    }

    private void flashSuccess() {
        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f, 0f);
        va.setDuration(650);
        va.addUpdateListener(a -> {
            float t = (float) a.getAnimatedValue();
            GradientDrawable gd = new GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT, new int[] {
                            blend(0xFFBB2E2E, 0xFF22BB66, t),
                            blend(C_RED, 0xFF33DD77, t),
                            blend(C_RED_D, 0xFF44EE88, t) });
            gd.setCornerRadius(dp(13));
            btnSubmit.setBackground(gd);
        });
        va.start();
    }

    private int blend(int c1, int c2, float t) {
        return Color.rgb(
                (int) (Color.red(c1) * (1 - t) + Color.red(c2) * t),
                (int) (Color.green(c1) * (1 - t) + Color.green(c2) * t),
                (int) (Color.blue(c1) * (1 - t) + Color.blue(c2) * t));
    }

    private void shake(View v) {
        ObjectAnimator a = ObjectAnimator.ofFloat(v, "translationX",
                0f, -dp(9), dp(9), -dp(7), dp(7), -dp(4), dp(4), 0f);
        a.setDuration(370);
        a.setInterpolator(new LinearInterpolator());
        a.start();
    }

    private void spring(View v, float from, float to, long dur) {
        AnimatorSet s = new AnimatorSet();
        s.playTogether(
                ObjectAnimator.ofFloat(v, "scaleX", from, to),
                ObjectAnimator.ofFloat(v, "scaleY", from, to));
        s.setDuration(dur);
        s.start();
    }

    private static final Object STATUS_TOKEN = new Object();
    private final Runnable statusClear = () -> {
    }; // dummy runnable làm marker

    private void status(String msg, int color) {
        tvStatus.setTag(msg);

        tvStatus.setTextColor(color);
        tvStatus.setVisibility(View.VISIBLE);
        tvStatus.setText("");

        int[] codePoints = msg.codePoints().toArray();
        for (int i = 0; i < codePoints.length; i++) {
            final String ch = new String(Character.toChars(codePoints[i]));
            final String expectedMsg = msg; // capture để check
            ui.postDelayed(() -> {
                // ✅ Chỉ append nếu vẫn đang hiện thị msg này
                if (expectedMsg.equals(tvStatus.getTag())) {
                    tvStatus.append(ch);
                }
            }, i * 20L);
        }
    }

    // ── CyberBg ───────────────────────────────────────────────────

    static class CyberBg extends View {
        private final Paint ptP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ptG = new Paint();
        private final Handler h = new Handler(Looper.getMainLooper());
        private final Random rng = new Random(7);

        private static final int N = 50;
        private final float[] px = new float[N], py = new float[N];
        private final float[] vx = new float[N], vy = new float[N];
        private final float[] pr = new float[N];
        private final int[] pa = new int[N];
        private int W, H;
        private float scanY = 0;

        CyberBg(Context c) {
            super(c);
            setLayerType(LAYER_TYPE_SOFTWARE, null);
            ptG.setColor(0x08FF4B4B);
            ptG.setStrokeWidth(0.5f);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            W = w;
            H = h;
            for (int i = 0; i < N; i++) {
                px[i] = rng.nextFloat() * W;
                py[i] = rng.nextFloat() * H;
                vx[i] = (rng.nextFloat() - 0.5f) * 0.5f;
                vy[i] = (rng.nextFloat() - 0.5f) * 0.5f;
                pr[i] = rng.nextFloat() * 1.6f + 0.5f;
                pa[i] = rng.nextInt(65) + 28;
            }
            this.h.post(loop);
        }

        private final Runnable loop = new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < N; i++) {
                    px[i] += vx[i];
                    py[i] += vy[i];
                    if (px[i] < 0)
                        px[i] = W;
                    if (px[i] > W)
                        px[i] = 0;
                    if (py[i] < 0)
                        py[i] = H;
                    if (py[i] > H)
                        py[i] = 0;
                }
                scanY += 1.1f;
                if (scanY > H + 55)
                    scanY = -55;
                invalidate();
                h.postDelayed(this, 16);
            }
        };

        @SuppressLint("DrawAllocation")
        @Override
        protected void onDraw(Canvas c) {
            c.drawColor(C_BG);
            for (float x = 0; x < W; x += 44)
                c.drawLine(x, 0, x, H, ptG);
            for (float y = 0; y < H; y += 44)
                c.drawLine(0, y, W, y, ptG);

            Paint sc = new Paint();
            sc.setShader(new LinearGradient(0, scanY - 48, 0, scanY + 48,
                    new int[] { 0x00FF0000, 0x12FF0000, 0x00FF0000 },
                    null, Shader.TileMode.CLAMP));
            c.drawRect(0, scanY - 48, W, scanY + 48, sc);

            Paint ln = new Paint(Paint.ANTI_ALIAS_FLAG);
            ln.setStyle(Paint.Style.STROKE);
            ln.setStrokeWidth(0.5f);
            for (int i = 0; i < N; i++) {
                ptP.setColor((pa[i] << 24) | (C_RED & 0xFFFFFF));
                ptP.setStyle(Paint.Style.FILL);
                c.drawCircle(px[i], py[i], pr[i], ptP);
                for (int j = i + 1; j < N; j++) {
                    float dx = px[i] - px[j], dy = py[i] - py[j];
                    float d = (float) Math.sqrt(dx * dx + dy * dy);
                    if (d < 90) {
                        int al = (int) ((1 - d / 90f) * 25);
                        ln.setColor((al << 24) | (C_RED & 0xFFFFFF));
                        c.drawLine(px[i], py[i], px[j], py[j], ln);
                    }
                }
            }

            int cx = W / 2, cy = H / 2;
            Paint vg = new Paint();
            vg.setShader(new RadialGradient(cx, cy,
                    (float) Math.sqrt(cx * cx + cy * cy),
                    new int[] { 0x00000000, 0x00000000, 0xCC000000 },
                    new float[] { 0f, 0.5f, 1f }, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, W, H, vg);
        }
    }

    // ── Helpers ───────────────────────────────────────────────────

    private LinearLayout vl() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private TextView tv(String t, float sp, int c, int s) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(c);
        v.setTextSize(sp);
        v.setTypeface(null, s);
        return v;
    }

    private View gap(int dpV) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(MP, dp(dpV)));
        return v;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @SuppressLint("ObsoleteSdkInt")
    private void hideUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private LinearLayout hBox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

}