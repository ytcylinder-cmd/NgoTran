package com.ngotran.ngotran;

import android.graphics.Path;
import android.view.View;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.PorterDuff;

import androidx.annotation.NonNull;

public class ESPView extends View {
    private final Paint strokePaint;
    private final int FrameDelay = 15;

    public ESPView(Context context) {
        super(context);
        strokePaint = new Paint();
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setAntiAlias(true);
        setFocusableInTouchMode(false);
        final Handler framehandler = new Handler();
        framehandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                invalidate();
                framehandler.postDelayed(this, FrameDelay);
            }
        }, FrameDelay);
    }

    @Override
    protected void onDraw(@NonNull Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        FloatingService.Draw(this, canvas);
    }

    public void DrawLine(Canvas cvs, int a, int r, int g, int b,
                         float strokewidth, float fromX, float fromY,
                         float toX, float toY) {
        strokePaint.setColor(Color.argb(a,r,g,b));
        strokePaint.setStrokeWidth(strokewidth);
        cvs.drawLine(fromX, fromY, toX, toY, strokePaint);
    }

    public void DrawBox(Canvas cvs, int a, int r, int g, int b,
                        float strokeWidth,
                        float left, float top,
                        float right, float bottom) {

        strokePaint.setColor(Color.argb(a, r, g, b));
        strokePaint.setStrokeWidth(strokeWidth);
        strokePaint.setStyle(Paint.Style.STROKE);

        cvs.drawRect(left, top, right, bottom, strokePaint);
    }

    public void DrawFilledBox(Canvas cvs, int a, int r, int g, int b,
                              float left, float top, float right, float bottom) {

        Paint fillPaint = new Paint();
        fillPaint.setStyle(Paint.Style.FILL);
        fillPaint.setAntiAlias(true);
        fillPaint.setColor(Color.argb(a, r, g, b));

        cvs.drawRect(left, top, right, bottom, fillPaint);
    }

    public void DrawText(Canvas cvs, int a, int r, int g, int b,
                         float size, float x, float y, String text) {

        Paint txtPaint = new Paint();
        txtPaint.setAntiAlias(true);
        txtPaint.setTextSize(size);
        txtPaint.setColor(Color.argb(a, r, g, b));
        txtPaint.setStyle(Paint.Style.FILL);

        cvs.drawText(text, x, y, txtPaint);
    }

    public float MeasureText(String txt, float size) {
        strokePaint.setTextSize(size);
        return strokePaint.measureText(txt);
    }

    public void DrawCircle(Canvas cvs, int a, int r, int g, int b,
                           float stroke, float cx, float cy, float radius) {
        strokePaint.setColor(Color.argb(a,r,g,b));
        strokePaint.setStrokeWidth(stroke);
        strokePaint.setStyle(Paint.Style.STROKE);
        cvs.drawCircle(cx, cy, radius, strokePaint);
    }

    public void DrawCircleFilled(Canvas cvs, int a, int r, int g, int b,
                                 float cx, float cy, float radius) {
        strokePaint.setColor(Color.argb(a,r,g,b));
        strokePaint.setStyle(Paint.Style.FILL);
        cvs.drawCircle(cx, cy, radius, strokePaint);
    }
    public void DrawFilledTriangle(Canvas canvas, int a, int r, int g, int b,
                                   float x1, float y1,
                                   float x2, float y2,
                                   float x3, float y3) {

        Paint paint = new Paint();
        paint.setColor(Color.argb(a, r, g, b));
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);

        Path path = new Path();
        path.moveTo(x1, y1);
        path.lineTo(x2, y2);
        path.lineTo(x3, y3);
        path.close();

        canvas.drawPath(path, paint);
    }
}